import { VehicleStore } from '../store/vehicle';
import { Request, Response } from 'express';

interface QueryParams {
  limit: number
  longitude: number
  latitude: number
}

export class FindVehiclesController {
  constructor(private readonly vehicleStore: VehicleStore) {}

  public async handle(req: Request<object, object, object, QueryParams>, res: Response): Promise<void> {
    const vehicles = await this.vehicleStore.findVehicles({
      limit: req.query.limit | 10,
      location: {
        longitude: req.query.longitude | 0.0,
        latitude: req.query.latitude | 0.0
      },
    });

   res.status(200).json({ vehicles: vehicles });
  }
}
